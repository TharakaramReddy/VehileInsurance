package com.cg.via.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


import com.cg.via.bean.Registration;

public class InsuranceDAOImpl implements InsuranceDAO {
	Registration reg=new Registration();
	Map<String,Registration> register=new HashMap<String,Registration>();
	public InsuranceDAOImpl() {
		register.put(reg.setVehicleNo(reg.getVehicleNo()), new Registration(reg.setVehicleType(reg.getVehicleType()),reg.setInsurancePeriod(reg.getInsurancePeriod()),reg.setAadharNo(reg.getAadharNo()),reg.setMobileNo(reg.getMobileNo())));
	}
	/*public Registration vechileInsuranceRegister(Registration reg) {
		System.out.println("putting details");
		//register.put(reg.setVehicleNo(reg.getVehicleNo()), new Registration(reg.setVehicleType(reg.getVehicleType()),reg.setInsurancePeriod(reg.getInsurancePeriod()),reg.setAadharNo(reg.getAadharNo()),reg.setMobileNo(reg.getMobileNo())));
		//register.put("THARAK",new Registration(2,2,22,222));
		System.out.println(register);
		return reg;
	}*/
	public ArrayList<Integer> vechileInsuranceRegister(Registration reg){
ArrayList<Integer> al=new ArrayList<Integer>();
		for(Entry<String, Registration> m: register.entrySet())
		{
			al.addAll((Collection<? extends Integer>) m);
		}
		return al;
	} 
	public Registration insuranceValidity() {
		// TODO Auto-generated method stub
		return null;
	}

}
