package com.cg.via.dao;

import java.util.ArrayList;

import com.cg.via.bean.Registration;

public interface InsuranceDAO {
        public ArrayList<Integer>  vechileInsuranceRegister(Registration reg);
        public Registration insuranceValidity();
}
