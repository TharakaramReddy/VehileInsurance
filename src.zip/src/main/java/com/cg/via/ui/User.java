package com.cg.via.ui;

import java.util.Scanner;

import com.cg.via.bean.Registration;
import com.cg.via.dao.InsuranceDAO;
import com.cg.via.service.InsuranceService;
import com.cg.via.service.InsuranceServiceImpl;

public class User {
	static Registration reg=new Registration();
	static InsuranceService inservice=new InsuranceServiceImpl();
	 static Scanner sc=new Scanner(System.in);
	private static void start() {
		System.out.println("Menu");
		System.out.println("Enter '1' for Vechile Insurance Registration\n '2' for Insurance Validity Check\n '3' for Exit");
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter details for registration");
			System.out.println("Enter Vehicle No");
		    String vehicleNo=reg.setVehicleNo(sc.next());
		    System.out.println("Enter vechile Type");
		    vechileType();
		    System.out.println("Enter insurance period");
		    int peroid=reg.setInsurancePeriod(sc.nextInt());
		    System.out.println("Enter aadher No");
		    long aadhar=reg.setAadharNo(sc.nextLong());
		    System.out.println("Enter Mobile No");
		    long mobile=reg.setMobileNo(sc.nextLong());
		 inservice.vehicleInsuranceRegister(reg);
			//System.out.println(reg);
		case 2:
			   
		case 3:
			System.exit(0);
			
		}
		
		
	}
	private static void vechileType() {
		System.out.println("enter '2' for 2 wheeler\n '4' for 4 wheeler");
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
			int vechileType=reg.setVehicleType(choice);
		case 2:
			int vechileType1=reg.setVehicleType(choice);
		}
		
	}
	public static void main(String[] args) {
		User user=new User();
		start();
	}

	

}
