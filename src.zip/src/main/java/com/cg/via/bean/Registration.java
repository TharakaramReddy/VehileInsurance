package com.cg.via.bean;

public class Registration {
private String vehicleNo;
private long aadharNo,mobileNo;
private int vehicleType,insurancePeriod;
public Registration(int vehicleType2, int insurancePeriod2, long aadharNo2, long mobileNo2) {
	
	this.getVehicleType();
	this.getInsurancePeriod();
	this.getAadharNo();
	this.getMobileNo();
	
}
public Registration() {
	// TODO Auto-generated constructor stub
}
/**
 * @return the vehicleNo
 */
public String getVehicleNo() {
	return vehicleNo;
}
/**
 * @param vehicleNo the vehicleNo to set
 * @return 
 */
public String setVehicleNo(String vehicleNo) {
	return this.vehicleNo = vehicleNo;
}
/**
 * @return the aadharNo
 */
public long getAadharNo() {
	return aadharNo;
}
/**
 * @param aadharNo the aadharNo to set
 * @return 
 */
public long setAadharNo(long aadharNo) {
	return this.aadharNo = aadharNo;
}
/**
 * @return the mobileNo
 */
public long getMobileNo() {
	return mobileNo;
}
/**
 * @param mobileNo the mobileNo to set
 * @return 
 */
public long setMobileNo(long mobileNo) {
	return this.mobileNo = mobileNo;
}
/**
 * @return the vehicleType
 */
public int getVehicleType() {
	return vehicleType;
}
/**
 * @param vehicleType the vehicleType to set
 * @return 
 */
public int setVehicleType(int vehicleType) {
	return this.vehicleType = vehicleType;
}
/**
 * @return the insurancePeriod
 */
public int getInsurancePeriod() {
	return insurancePeriod;
}
/**
 * @param insurancePeriod the insurancePeriod to set
 * @return 
 */
public int setInsurancePeriod(int insurancePeriod) {
	return this.insurancePeriod = insurancePeriod;
}

}
