package com.cg.via.service;

import com.cg.via.bean.Registration;

public interface InsuranceService {
   public Registration vehicleInsuranceRegister(Registration reg);
   public Registration insuranceValidity();
}
