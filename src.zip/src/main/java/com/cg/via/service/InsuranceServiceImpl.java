package com.cg.via.service;

import com.cg.via.bean.Registration;
import com.cg.via.dao.InsuranceDAO;
import com.cg.via.dao.InsuranceDAOImpl;

public class InsuranceServiceImpl implements InsuranceService {
	InsuranceDAO insur=new InsuranceDAOImpl();

	public Registration vehicleInsuranceRegister(Registration reg) {
		 insur.vechileInsuranceRegister(reg);
		 return reg;
	}

	public Registration insuranceValidity() {
		
		return insur.insuranceValidity();
	}

}
